/* SPDX-FileCopyrightText: © 2022-2024 Decompollaborate */
/* SPDX-License-Identifier: MIT */

#ifndef RABBITIZER_H
#define RABBITIZER_H
#pragma once

#include "common/Utils.h"
#include "common/RabbitizerVersion.h"
#include "common/RabbitizerConfig.h"

#include "instructions/RabbitizerOperandType.h"
#include "instructions/RabbitizerInstrId.h"
#include "instructions/RabbitizerInstrSuffix.h"
#include "instructions/RabbitizerInstrDescriptor.h"
#include "instructions/RabbitizerRegister.h"
#include "instructions/RabbitizerRegisterDescriptor.h"
#include "instructions/RabbitizerInstruction.h"
#include "instructions/RabbitizerInstructionRsp.h"
#include "instructions/RabbitizerInstructionR3000GTE.h"
#include "instructions/RabbitizerInstructionR4000Allegrex.h"
#include "instructions/RabbitizerInstructionR5900.h"

#include "analysis/RabbitizerTrackedRegisterState.h"
#include "analysis/RabbitizerLoPairingInfo.h"
#include "analysis/RabbitizerRegistersTracker.h"

#endif
